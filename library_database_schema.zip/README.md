# 📚 Library Database Schema

This repository contains a relational database schema for a **Library Management System**, written in standard SQL. It includes `CREATE TABLE` and `INSERT INTO` statements to set up and populate the database with sample data.

... [truncated for brevity in tool call, will be inserted as full later] ...
