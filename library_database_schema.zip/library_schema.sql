
-- TABLE CREATION

CREATE TABLE Authors (
    AuthorID INT PRIMARY KEY,
    Name VARCHAR(100) NOT NULL,
    Bio TEXT
);

CREATE TABLE Categories (
    CategoryID INT PRIMARY KEY,
    CategoryName VARCHAR(100) NOT NULL
);

CREATE TABLE Books (
    BookID INT PRIMARY KEY,
    Title VARCHAR(255) NOT NULL,
    ISBN VARCHAR(13) UNIQUE,
    PublicationYear INT,
    CategoryID INT,
    FOREIGN KEY (CategoryID) REFERENCES Categories(CategoryID)
);

CREATE TABLE BookAuthors (
    BookID INT,
    AuthorID INT,
    PRIMARY KEY (BookID, AuthorID),
    FOREIGN KEY (BookID) REFERENCES Books(BookID),
    FOREIGN KEY (AuthorID) REFERENCES Authors(AuthorID)
);

CREATE TABLE Members (
    MemberID INT PRIMARY KEY,
    Name VARCHAR(100) NOT NULL,
    Email VARCHAR(100) UNIQUE NOT NULL,
    MembershipDate DATE
);

CREATE TABLE Librarians (
    LibrarianID INT PRIMARY KEY,
    Name VARCHAR(100),
    Email VARCHAR(100) UNIQUE
);

CREATE TABLE Loans (
    LoanID INT PRIMARY KEY,
    BookID INT,
    MemberID INT,
    LibrarianID INT,
    LoanDate DATE,
    ReturnDate DATE,
    FOREIGN KEY (BookID) REFERENCES Books(BookID),
    FOREIGN KEY (MemberID) REFERENCES Members(MemberID),
    FOREIGN KEY (LibrarianID) REFERENCES Librarians(LibrarianID)
);

-- INSERT DATA

INSERT INTO Authors (AuthorID, Name, Bio) VALUES
(1, 'J.K. Rowling', 'British author, best known for Harry Potter series.'),
(2, 'George Orwell', 'Author of 1984 and Animal Farm.'),
(3, 'Agatha Christie', 'Famous for mystery novels.'),
(4, 'Dan Brown', 'Known for The Da Vinci Code.');

INSERT INTO Categories (CategoryID, CategoryName) VALUES
(1, 'Fiction'),
(2, 'Science Fiction'),
(3, 'Mystery'),
(4, 'History'),
(5, 'Biography');

INSERT INTO Books (BookID, Title, ISBN, PublicationYear, CategoryID) VALUES
(101, 'Harry Potter and the Sorcerer''s Stone', '9780747532743', 1997, 1),
(102, '1984', '9780451524935', 1949, 2),
(103, 'Murder on the Orient Express', '9780007119318', 1934, 3),
(104, 'The Da Vinci Code', '9780307474278', 2003, 3);

INSERT INTO BookAuthors (BookID, AuthorID) VALUES
(101, 1),
(102, 2),
(103, 3),
(104, 4);

INSERT INTO Members (MemberID, Name, Email, MembershipDate) VALUES
(201, 'Alice Johnson', 'alice.johnson@example.com', '2022-01-15'),
(202, 'Bob Smith', 'bob.smith@example.com', '2023-06-10'),
(203, 'Carol White', 'carol.white@example.com', '2024-03-20');

INSERT INTO Librarians (LibrarianID, Name, Email) VALUES
(301, 'David Miller', 'david.miller@library.org'),
(302, 'Eva Green', 'eva.green@library.org');

INSERT INTO Loans (LoanID, BookID, MemberID, LibrarianID, LoanDate, ReturnDate) VALUES
(401, 101, 201, 301, '2025-06-01', '2025-06-15'),
(402, 102, 202, 302, '2025-06-10', NULL),
(403, 103, 203, 301, '2025-06-12', '2025-06-19');
